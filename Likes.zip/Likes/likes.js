let like
like = 9

function like(element) {
    like++
    element.innerText = count + "like(s)"
}

let like2
like2 = 12

function like2(element) {
    like2++
    element.innerText = like2
}

let like3
like3 = 9

function like3(element) {
    like3++
    element.innerText = like3
}